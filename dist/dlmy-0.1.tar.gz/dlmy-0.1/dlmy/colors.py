#!/usr/bin/env python3
class col:
    blue = '\033[94m'
    ok = '\033[92m'
    warn = '\033[93m'
    fail = '\033[91m'
    end = '\033[0m'
